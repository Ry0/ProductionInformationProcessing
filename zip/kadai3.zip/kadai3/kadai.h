#ifndef _KADAI_DEF_
#define _KADAI_DEF_
#include "kadai1A.h"
#include "kadai3.h"
#include "Struct.h"
#endif