#include "kadai.h"

int main(){
  // 3次ベジエ曲線テスト
  // draw_bezier3();

  // ベジエ曲面を描く
  draw_bezier3_surface();

  OpenGnuplot();

  return 0;
}