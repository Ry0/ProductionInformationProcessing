#include "kadai.h"

int main(){

  // 課題1
  double tetra_pos[TETRA_V_NUM][VEC_SIZE];
  double triprism_pos[TRIPRISM_V_NUM][VEC_SIZE];
  stlb_k01(tetra_pos, triprism_pos);

  // 課題2
  TransformPositionAll((char*)"Tetra-Triprism");

  return 0;
}