#ifndef _KADAI_DEF_
#define _KADAI_DEF_
#include "kadai1A.h"
#include "kadai2A.h"
#include "Struct.h"
#endif